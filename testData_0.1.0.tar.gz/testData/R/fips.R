
#' fips dataset
#'
#' @description a fips dataset with 3 columns: FIPS codes, county names, state names
#'
#' @docType data
#' @usage data(fips)
#' @keywords datasets
#'
#' @examples
#' data(fips)
#'
"fips"